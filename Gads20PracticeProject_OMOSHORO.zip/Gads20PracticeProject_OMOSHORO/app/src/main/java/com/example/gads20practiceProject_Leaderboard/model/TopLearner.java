package com.example.gads20practiceProject_Leaderboard.model;
/*
 Project Author: OluwaKemmy Omoshoro
 Project Owner: GADS2020 Android Project
 Project name: Andela Leader Board project.

 */

public class TopLearner {
    private String name;
    private String country;
    private int hours;
    private String badgeUrl;

    //Constructors
    public TopLearner (String name,String country,int hours,String badgeUrl)
    {
        this.name = name;
        this.country=country;
        this.hours = hours;
        this.badgeUrl = badgeUrl;

    }//publicTopLearner

    //get-methods & set-Methods
    public String getName() {
        return name;
    }//getName()
    public void setName(String name) {
        this.name = name;
    }//setName()

    public String getCountry() {
        return country;
    }//getCountry()
    public void setCountry(String country) {
        this.country = country;
    }//setCountry()

    public int getHours() {
        return hours;
    }//getHours()
    public void setScore(int hours) {
        this.hours = hours;
    }//setHours()

    public String getBadgeUrl() {
        return badgeUrl;
    }//getBadUrl
    public void setBadgeUrl(String badgeUrl) {
        this.badgeUrl = badgeUrl;
    }//setBadgeUrl

    //String Builder
    @Override
    public String toString()
    {
        return "TopLearner{" +
                "name='" + name +'\'' +
                ", country='" + country +'\'' +
                ", hours=" + hours +
                ", badgeUrl='" + badgeUrl +'\'' +
                '}';

    }//String toString
}//TopLearner
