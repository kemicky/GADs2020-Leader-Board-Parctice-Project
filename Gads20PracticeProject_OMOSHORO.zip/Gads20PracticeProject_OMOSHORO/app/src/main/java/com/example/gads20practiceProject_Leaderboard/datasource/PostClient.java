package com.example.gads20practiceProject_Leaderboard.datasource;

/*
 Project Author: OluwaKemmy Omoshoro
 Project Owner: GADS2020 Android Project
 Project name: Andela Leader Board project.
 */


import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


    //PostClient public class constructor method
    public class PostClient{
        private static final String Base_URL = "https://gadsapi.herokuapp.com/";
        public static final String GOOGLE_DOCS_BASE_URL = "https://docs.google.com/forms/d/e/";
        private static Client client;
        private static PostClient doc;

     public static Client getTopAchievers()
     {
         //Build Retrofit
         Retrofit retrofit = new Retrofit.Builder()
                 .baseUrl(Base_URL)
                 .addConverterFactory(GsonConverterFactory.create())
                 .build();

         Client  client = retrofit.create(Client.class);
         return  client;
     } //PostClient


        public static PostClient getGoogleDocs(){
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(GOOGLE_DOCS_BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            PostClient doc = retrofit.create(PostClient.class);
            return  doc;
        }





    }//postClient




