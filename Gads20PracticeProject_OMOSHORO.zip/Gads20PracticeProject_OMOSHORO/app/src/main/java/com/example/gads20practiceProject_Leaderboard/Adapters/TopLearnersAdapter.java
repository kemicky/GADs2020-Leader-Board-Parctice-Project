package com.example.gads20practiceProject_Leaderboard.Adapters;

/*
 Project Author: OluwaKemmy Omoshoro
 Project Owner: GADS2020 Android Project
 Project name: Andela Leader Board project.
 */


import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.gads20practiceProject_Leaderboard.R;
import com.example.gads20practiceProject_Leaderboard.model.TopLearner;

import java.util.List;

//Creating the Learners adaptors.
public class TopLearnersAdapter extends RecyclerView.Adapter<TopLearnersAdapter.LearnersViewHolder>
{

    List<TopLearner> learningLeadersList ;
    Context mContext;

    public TopLearnersAdapter(List<TopLearner> learningLeadersList, Context context) {
        this.learningLeadersList = learningLeadersList;
        mContext = context;
    }

    public static class LearnersViewHolder extends RecyclerView.ViewHolder {

        public TextView nameTextView;
        public TextView countryTextView;
        public ImageView badgeImageView;


        public LearnersViewHolder(@NonNull View itemView) {
            super(itemView);

            nameTextView = itemView.findViewById(R.id.learnerName);
            countryTextView = itemView.findViewById(R.id.countryAndScoreOrHours);
            badgeImageView = itemView.findViewById(R.id.learnerBadge);

        }
    }


    @NonNull
    @Override
    public LearnersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View learnerView = LayoutInflater.from(parent.getContext()).inflate(R.layout.leaders_list_item, parent, false);
        LearnersViewHolder learnersViewHolder = new LearnersViewHolder(learnerView);

        return learnersViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull LearnersViewHolder holder, int position) {

        LearningLeaders currentLearner = learningLeadersList.get(position);

        holder.nameTextView.setText(currentLearner.getName());

        holder.countryTextView.setText(currentLearner.getHours() + " learning hours, " + currentLearner.getCountry());

        Picasso.get()
                .load(Uri.parse(currentLearner.getBadgeUrl()))

                .into(holder.badgeImageView);


    }

    @Override
    public int getItemCount() {
        return learningLeadersList.size();
    }



}
