package com.example.gads20practiceProject_Leaderboard;
/*
 Project Author: OluwaKemmy Omoshoro
 Project Owner: GADS2020 Android Project
 Project name: Andela Leader Board project.
 */

//imports

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gads20practiceProject_Leaderboard.Adapters.SkillAdapter;
import com.example.gads20practiceProject_Leaderboard.R;
import com.example.gads20practiceProject_Leaderboard.datasource.PostClient;
import com.example.gads20practiceProject_Leaderboard.model.SkillIQ;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SkillFragment extends Fragment {
    RecyclerView recyclerView;
    private SkillAdapter skillAdapter;
    private ProgressBar learnersPBar;

     //Empty Constructor
    public SkillFragment()
    {

    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the confirm_submission for this fragment
        View rootView = inflater.inflate(R.layout.fragment_skill_iq, container, false);
        recyclerView = rootView.findViewById(R.id.recyclerViewSkills);
        learnersPBar = rootView.findViewById(R.id.progressBarSkills);

        getSkillLeaders();

        return rootView;
    }

    private void getSkillLeaders() {
        PostClient.getTopAchievers()
                .getTopSkill()
                .enqueue(new Callback<List<SkillIQ>>() {
                    @Override
                    public void onResponse(Call<List<SkillIQ>> call, Response<List<SkillIQ>> response) {
                        if (response.isSuccessful()) {
                            List<SkillIQ> skillIqList = response.body();

                            skillAdapter = new SkillAdapter(skillIqList, getActivity());
                            recyclerView.setAdapter(skillAdapter);

                            recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

                            learnersPBar.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onFailure(Call<List<SkillIQ>> call, Throwable t) {
                        learnersPBar.setVisibility(View.VISIBLE);
                    }


                });


    }


}//SkillFragments
