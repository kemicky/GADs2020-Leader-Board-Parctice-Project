package com.example.gads20practiceProject_Leaderboard;
/*
 Project Author: OluwaKemmy Omoshoro
 Project Owner: GADS2020 Android Project
 Project name: Andela Leader Board project.
 */

//imports

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gads20practiceProject_Leaderboard.Adapters.TopLearnersAdapter;
import com.example.gads20practiceProject_Leaderboard.R;
import com.example.gads20practiceProject_Leaderboard.datasource.PostClient;
import com.example.gads20practiceProject_Leaderboard.model.TopLearner;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TopLearnerFragment extends Fragment {

    private RecyclerView recyclerView;

    private TopLearnersAdapter learnersAdapter;

    private ProgressBar learnersBar;


    //Empty Constructor
    public TopLearnerFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the confirm_submission for this fragment
        View rootView = inflater.inflate(R.layout.fragment_top_learner, container, false);
        recyclerView = rootView.findViewById(R.id.leadersRecyclerView);
        learnersBar = rootView.findViewById(R.id.progressBarLeaders);

        getLearningLeaders();


        return rootView;
    }

    private void getLearningLeaders() {

        PostClient.getTopAchievers()
                .getTopLearners()
                .enqueue(new Callback<List<TopLearner>>() {
                    @Override
                    public void onResponse(Call<List<TopLearner>> call, Response<List<TopLearner>> response) {

                        if (response.isSuccessful()) {
                            List<TopLearner> learnersList = response.body();
                            learnersAdapter = new TopLearnersAdapter(learnersList, getActivity().getApplicationContext());
                            recyclerView.setAdapter(learnersAdapter);

                            recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

                            learnersBar.setVisibility(View.GONE);


                        }

                    }

                    @Override
                    public void onFailure(Call<List<TopLearner>> call, Throwable t) {
                        learnersBar.setVisibility(View.VISIBLE);
                    }



                });


    }











}//Top learner fragments
