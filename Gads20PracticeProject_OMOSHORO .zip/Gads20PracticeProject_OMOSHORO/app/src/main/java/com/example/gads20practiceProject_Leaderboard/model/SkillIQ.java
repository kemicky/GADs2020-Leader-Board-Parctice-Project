package com.example.gads20practiceProject_Leaderboard.model;
/*
 Project Author: OluwaKemmy Omoshoro
 Project Owner: GADS2020 Android Project
 Project name: Andela Leader Board project.
 */
public class SkillIQ {
    private String name;
    private String country;
    private int score;
    private String badgeUrl;

    //Constructors
    public SkillIQ(String name,String country,int score,String badgeUrl)
    {
        this.name = name;
        this.country=country;
        this.score = score;
        this.badgeUrl = badgeUrl;

    }//publicSkillIQ

    //get-methods & set-Methods
    public String getName() {
        return name;
    }//getName()
    public void setName(String name) {
        this.name = name;
    }//setName()

    public String getCountry() {
        return country;
    }//getCountry()
    public void setCountry(String country) {
        this.country = country;
    }//setCountry()

    public int getScore() {
        return score;
    }//getScore()
    public void setScore(int score) {
        this.score = score;
    }//setScore()

    public String getBadgeUrl() {
        return badgeUrl;
    }//getBadUrl
    public void setBadgeUrl(String badgeUrl) {
        this.badgeUrl = badgeUrl;
    }//setBadgeUrl

    //String Builder
    @Override
    public String toString()
    {
        return "SkillIQ{" +
                "name='" + name +'\'' +
                ", country='" + country +'\'' +
                ", score=" + score +
                ", badgeUrl='" + badgeUrl +'\'' +
                '}';

    }//String toString

}//class SkillIQ
