package com.example.gads20practiceProject_Leaderboard;


/*
 Project Author: OluwaKemmy Omoshoro
 Project Owner: GADS2020 Android Project
 Project name: Andela Leader Board project.
 */


//imports
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;


public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home2);
        setSplashScreen();
    }

    private void setSplashScreen() {
        Thread thread = new Thread(){
            public void run(){
                try {
                    sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                finally {

                    Intent intent = new Intent(Home.this,MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        }; thread.start();

    }




    }//home