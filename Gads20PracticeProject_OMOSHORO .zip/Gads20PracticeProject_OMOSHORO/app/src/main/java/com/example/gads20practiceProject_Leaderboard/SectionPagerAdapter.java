package com.example.gads20practiceProject_Leaderboard;

/*
 Project Author: OluwaKemmy Omoshoro
 Project Owner: GADS2020 Android Project
 Project name: Andela Leader Board project.
 */


//imports

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.gads20practiceProject_Leaderboard.R;

public class SectionPagerAdapter extends FragmentPagerAdapter
{
    private static final int[] TAB_TITLES = new int[]{R.string.top_learner_tab, R.string.skill_iq_Tab};
    Context mContext;


    public SectionPagerAdapter(Context context, @NonNull FragmentManager fm) {
        super(fm);
        mContext = context;

    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        // Fragment fragment = null;
        if (position==0){
            return    new TopLearnerFragment();
        }else
            //if(position==1){
            return new SkillFragment();


    }

    @Override
    public int getCount() {
        return 2;
    }


    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return  mContext.getResources().getString(TAB_TITLES[position]);
    }



}//SectionPager
